package tools.vitruv.methodologisttemplate.vsum.karaceing;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;

import tools.vitruv.change.composite.description.PropagatedChange;
import tools.vitruv.change.composite.description.VitruviusChange;
import tools.vitruv.methodologisttemplate.consistency.EMFUtil;

/**
 * Serialises one change propagation of the VSUM as JSON (only used when
 * {@link KARaceIngTestBase#SNAPSHOT_PROPERTY} is set): for every propagated change the atomic changes of the
 * original change (made in the view, or by the previous propagation step) and of the consequential changes
 * (made by the reactions), and the dialogs answered on the way. Changes and dialogs are EMF objects and are
 * written generically through their structural features.
 */
final class PropagationLog {

    private PropagationLog() {
    }

    static String step(Iterable<PropagatedChange> changes) {
        List<String> parts = new ArrayList<>();
        try {
            for (PropagatedChange change : changes) {
                parts.add("{\"original\":" + changes(change.getOriginalChange()) + ",\"consequential\":" + changes(change.getConsequentialChanges())
                        + ",\"interactions\":" + interactions(change) + "}");
            }
        } catch (RuntimeException e) {
            parts.add("{\"error\":" + str(String.valueOf(e)) + "}");
        }
        return "[" + String.join(",", parts) + "]";
    }

    private static String changes(VitruviusChange<EObject> change) {
        List<String> out = new ArrayList<>();
        if (change != null) {
            for (Object c : change.getEChanges()) {
                out.add(object((EObject) c));
            }
        }
        return "[" + String.join(",", out) + "]";
    }

    private static String interactions(PropagatedChange change) {
        List<String> out = new ArrayList<>();
        for (VitruviusChange<EObject> c : List.of(change.getOriginalChange(), change.getConsequentialChanges())) {
            if (c == null) {
                continue;
            }
            for (Object i : c.getUserInteractions()) {
                out.add(object((EObject) i));
            }
        }
        return "[" + String.join(",", out) + "]";
    }

    /** {"type": EClass name, feature: value, ...} for all set features of an atomic change or interaction. */
    private static String object(EObject o) {
        List<String> fields = new ArrayList<>();
        fields.add("\"type\":" + str(o.eClass().getName()));
        for (EStructuralFeature f : o.eClass().getEAllStructuralFeatures()) {
            Object v = o.eGet(f);
            if (v == null || (v instanceof Collection<?> col && col.isEmpty())) {
                continue;
            }
            fields.add(str(f.getName()) + ":" + value(v));
        }
        return "{" + String.join(",", fields) + "}";
    }

    private static String value(Object v) {
        if (v instanceof Collection<?> col) {
            List<String> out = new ArrayList<>();
            col.forEach(x -> out.add(value(x)));
            return "[" + String.join(",", out) + "]";
        }
        if (v instanceof EStructuralFeature f) {
            return str(f.getName());
        }
        if (v instanceof EClass c) {
            return str(c.getName());
        }
        if (v instanceof EObject e) {
            String file = e.eResource() == null ? null : e.eResource().getURI().lastSegment();
            return "{\"name\":" + str(EMFUtil.getNameOf(e)) + ",\"cls\":" + str(e.eClass().getName()) + (file == null ? "" : ",\"file\":" + str(file)) + "}";
        }
        if (v instanceof Number || v instanceof Boolean) {
            return str(String.valueOf(v));
        }
        return str(String.valueOf(v));
    }

    private static String str(String s) {
        if (s == null) {
            return "null";
        }
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> {
                    if (c < 0x20) {
                        b.append(String.format("\\u%04x", (int) c));
                    } else {
                        b.append(c);
                    }
                }
            }
        }
        return b.append('"').toString();
    }

}
