"""Generate the initial state of the KA-RaceIng product line as a persisted VSUM.

Inputs : the stakeholder-role feature models (SPL_FeatureModels_v2_Stakeholders/models),
         the requirement mappings (mapping/*.csv) and the three car configurations.
Output : <OUT> is the storage folder of a VSUM, in the same layout that Vitruvius writes itself
         (compare vsumexample/):
           karaceing.uvl, karaceing.config, prj.requirements, des.cad, crash.cad, kin.cad, aero.cad,
           elec.electrical, sim.simulink, thermo.thermal, val.testbench, karaceing.bom, des.brakesystem
           vsum/models.models                   the model URIs of the VSUM
           vsum/uuid.uuid                       UUID of every model element (UUID|hierarchical id)
           vsum/correspondences.correspondence  the correspondence model (ReactionsCorrespondence)
         Vitruvius stores absolute file URIs in models.models and uuid.uuid; they are written with
         the placeholder file:/KARACEING_INITIAL_STATE, which the test replaces by the folder the VSUM
         is copied to. The hrefs in correspondences.correspondence are relative ("../des.cad#//...").

The UVL and configuration metamodels are used exactly as provided: the feature model contains the
feature tree only (typed features carry an Integer attribute); cross-tree constraints cannot be
expressed with the UVL metamodel and are not part of the model (they are only used here to check
that the three configurations are valid). Configurations have no name: EV3, CV2, CV1 are the
configurations 0, 1, 2 of the configuration model.

Correspondence tags: ''            feature <-> artefact (FCPR), uvl <-> config, feature <-> config feature
      'overlap'     artefact <-> semantically overlapping artefact of another domain (or the BOM)
      'requirement' requirement (PRJ spec) <-> artefact realising a feature the requirement is mapped to
"""
import csv, glob, json, os, re, sys
from collections import OrderedDict, defaultdict
from pyecore.resources import ResourceSet, URI
from pyecore.resources.xmi import XMIResource

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import uvlcheck as U

TEMPLATE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ECORE = os.path.join(TEMPLATE_DIR, 'model', 'src', 'main', 'ecore')
# the stakeholder-role feature models next to the template (KARaceIngSPLCaseStudyVersion1/SPL_FeatureModels_v2_Stakeholders)
SPL = os.environ.get('KARACEING_SPL', os.path.join(os.path.dirname(TEMPLATE_DIR), 'SPL_FeatureModels_v2_Stakeholders'))
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(TEMPLATE_DIR, 'vsum', 'src', 'test', 'resources', 'initialstate')
os.makedirs(OUT, exist_ok=True)

ROLES = ['prj', 'des', 'crash', 'kin', 'aero', 'thermo', 'elec', 'sim', 'val']
CAD_ROLES = ['des', 'crash', 'kin', 'aero']
CARS = [('EV3', 'EV3 (25e)', 'EV3_25e.json', 'EV3_25e'), ('CV2', 'CV2 (25h)', 'CV2_25h_Hydrogen.json', 'CV2_25h_Hydrogen'),
        ('CV1', 'CV1 (19c)', 'CV1_19c_Petrol.json', 'CV1_19c_Petrol')]

# ----------------------------------------------------------------------------- metamodels
rs = ResourceSet()
MM = {}
for f in ['UVL', 'configurationsMM', 'cad', 'requirements', 'thermal', 'testbench', 'electrical', 'bom', 'brakesystem', 'simuLink']:
    p = rs.get_resource(URI(f'{ECORE}/{f}.ecore')).contents[0]
    rs.metamodel_registry[p.nsURI] = p
    MM[f] = p


def C(mm, name):
    return MM[mm].getEClassifier(name)


def new(mm, cls, **kw):
    o = C(mm, cls)()
    for k, v in kw.items():
        if v is None:
            continue
        if isinstance(v, list):
            getattr(o, k).extend(v)
        else:
            setattr(o, k, v)
    return o


# ----------------------------------------------------------------------------- feature model
M = f'{SPL}/models/'
feats, cons, roots = U.load_composite([(M + 'KARaceIngSPL.uvl', '')] + [(M + r.upper() + '.uvl', r + '.') for r in ROLES])
DOMAIN_ROOT = {r: roots[r + '.'] for r in ROLES}              # 'des' -> 'des.DesignEngineering'
children = defaultdict(list)                                     # parent -> [child] in model order
groups = OrderedDict()                                           # gkey -> (parent, kind, [children])
for f, d in feats.items():
    if d['parent']:
        children[d['parent']].append(f)
        groups.setdefault(d['gkey'], (d['parent'], d['group'], []))[2].append(f)
for r in ROLES:
    feats[DOMAIN_ROOT[r]]['parent'] = 'KARaceIngSPL'


def short(q):
    return q.split('.')[-1]


def role_of(q):
    return q.split('.')[0] if '.' in q else None


def is_leaf(q):
    return not children.get(q)


# UVL model
GROUP_CLS = {'mandatory': 'Mandatory', 'optional': 'Optional', 'alternative': 'Alternative', 'or': 'Or'}
FEATURE = {}


def mk_feature(q):
    d = feats[q]
    t = d.get('type')
    f = new('UVL', 'Feature', name=short(q))
    if t:                                   # typed feature: the UVL metamodel's Integer/Float/String attribute
        f.attribute.append(new('UVL', {'Integer': 'Integer', 'Real': 'Float', 'String': 'String'}[t]))
    FEATURE[q] = f
    return f


root_feature = mk_feature('KARaceIngSPL')
root_group = new('UVL', 'Mandatory')
root_group.feature.append(root_feature)
root_feature.group = root_group


def build_subtree(q):
    f = FEATURE[q]
    for gkey, (parent, kind, chs) in groups.items():
        if parent != q:
            continue
        g = new('UVL', GROUP_CLS[kind])
        f.children.append(g)
        for c in chs:
            cf = mk_feature(c)
            g.feature.append(cf)
            cf.group = g
            build_subtree(c)


for r in ROLES:                                  # one Mandatory group per domain root (pattern requirement)
    g = new('UVL', 'Mandatory')
    root_feature.children.append(g)
    df = mk_feature(DOMAIN_ROOT[r])
    g.feature.append(df)
    df.group = g
    build_subtree(DOMAIN_ROOT[r])
assert len(FEATURE) == len(feats), (len(FEATURE), len(feats))

# constraints (only used to check the configurations; the UVL metamodel cannot express them)
PREC = {'iff': 1, 'imp': 2, 'or': 3, 'and': 4}


def text(e, parent=0):
    k = e[0]
    if k == 'var':
        return e[1]
    if k == 'num':
        v = e[1]
        return str(int(v)) if float(v).is_integer() else str(v)
    if k == 'not':
        inner = text(e[1], 5)
        return '!' + inner
    if k in PREC:
        op = {'iff': '<=>', 'imp': '=>', 'or': '|', 'and': '&'}[k]
        s = f'{text(e[1], PREC[k] + (1 if k == "imp" else 0))} {op} {text(e[2], PREC[k])}'
        return f'({s})' if PREC[k] < parent or (k == 'imp' and parent == PREC[k] + 1) else s
    if k == 'cmp':
        return f'{text(e[2], 6)} {e[1]} {text(e[3], 6)}'
    if k == 'ar':
        return f'({text(e[2], 7)} {e[1]} {text(e[3], 7)})'
    raise ValueError(e)


CONSTRAINTS = []                                            # (name, text, expr) - only used to check the configurations
for i, (e, raw, src) in enumerate(cons, 1):
    CONSTRAINTS.append((f'C{i:03d}', text(e), e))

uvl = new('UVL', 'UVLModel', tree=new('UVL', 'FeatureTree', root=root_group))

# ----------------------------------------------------------------------------- configurations
CFG = {}
for code, label, fn, col in CARS:
    d = json.load(open(f'{SPL}/configurations/{fn}'))
    sel = dict(d['config'])
    sel.update(d.get('example_completion') or {})
    CFG[code] = sel


def selected(code, q):
    v = CFG[code].get(q)
    return bool(v) if not isinstance(v, (int, float)) or isinstance(v, bool) else True


def check_config(code):
    """Python twin of the Java ConfigurationChecker: returns the list of issues."""
    sel = {q: selected(code, q) for q in feats}
    vals = {q: float(CFG[code][q]) for q in feats if feats[q].get('type') and not isinstance(CFG[code].get(q), bool) and CFG[code].get(q) is not None}
    issues = []
    for gkey, (p, kind, chs) in list(groups.items()) + [(('root', r), ('KARaceIngSPL', 'mandatory', [DOMAIN_ROOT[r]])) for r in ROLES]:
        if not sel[p]:
            for c in chs:
                if sel[c]:
                    issues.append(f'VIOLATED: {short(c)} selected without parent {short(p)}')
            continue
        n = sum(sel[c] for c in chs)
        if kind == 'mandatory' and n != len(chs):
            issues.append(f'VIOLATED: mandatory group of {short(p)}')
        if kind == 'alternative' and n != 1:
            issues.append(f'VIOLATED: alternative group of {short(p)}')
        if kind == 'or' and n < 1:
            issues.append(f'VIOLATED: or group of {short(p)}')

    def ev(e):
        k = e[0]
        if k == 'var': return sel[e[1]]
        if k == 'not': return not ev(e[1])
        if k == 'and': return ev(e[1]) and ev(e[2])
        if k == 'or': return ev(e[1]) or ev(e[2])
        if k == 'imp': return (not ev(e[1])) or ev(e[2])
        if k == 'iff': return ev(e[1]) == ev(e[2])
        if k == 'cmp':
            try:
                return U.eval_arith(e, vals)
            except KeyError:
                return False
        raise ValueError(k)
    for name, txt, e in CONSTRAINTS:
        if not ev(e):
            issues.append(f'VIOLATED: {name} {txt}')
    return issues


config_model = new('configurationsMM', 'ConfigurationModel')
CONFIG_FEATURE = {}
for code, label, fn, col in CARS:
    iss = check_config(code)
    assert not iss, (code, iss)
    conf = new('configurationsMM', 'Configuration', PLVersion=1)
    CONFIG_FEATURE[code] = {}
    for q in FEATURE:                                     # same order as the feature tree
        cf = new('configurationsMM', 'Feature', name=short(q), isSelected=selected(code, q))
        conf.feature.append(cf)
        CONFIG_FEATURE[code][q] = cf
    config_model.configuration.append(conf)

# ----------------------------------------------------------------------------- domain artefacts
CORR = []                      # (left, right, tag); left/right = object or '<file>#name:X' reference
UVL_MODEL_LITERAL = object()   # stands for uvlPackage.Literals.UVL_MODEL (correspondence used by uvl2uvl)
REALISATION = {}               # qualified feature -> (file, name) of its main artefact


def ref(file, name=None):
    return f'{file}#' + (f'name:{name}' if name is not None else '')


class Model:
    """Domain model under construction; enforces unique names per file."""
    def __init__(self, file, root, name_attr='name'):
        self.file, self.root, self.names, self.by_name = file, root, set(), {}
        self.name_attr = name_attr

    def reg(self, obj, name):
        assert name not in self.names, (self.file, name)
        self.names.add(name)
        self.by_name[name] = obj
        return obj


def feature_corr(q, file, name):
    CORR.append((f'karaceing.uvl#name:{short(q)}', ref(file, name), ''))
    REALISATION.setdefault(q, (file, name))


def kw_kind(n, table, default):
    for k, v in table:
        if k.lower() in n.lower():
            return v
    return default


# --- overrides and scenario artefacts ------------------------------------------------
# name overrides: the artefact realising a feature has another name than the feature
NAME_OVERRIDE = {'des.TankSystemIntegration': 'CV1ChassisAdapterFrame'}
# leaf features whose default realisation content is replaced: q -> [(class, name, attrs)]
LEAF_CONTENT = {
    'crash.MechanicallyAttachedBracing': [('Box', 'LugJoints', {}), ('Box', 'SleeveJoints', {})],
    'thermo.BackfireProtection': [('AnalysisCase', 'BackfireReliefAnalysis', {'method': '1D gas dynamics', 'result': 'relief valve opens at 3 bar', 'passed': True})],
    'thermo.EngineConversionToHydrogen': [('AnalysisCase', 'EngineConversionAnalysis', {'method': '0D/1D engine simulation', 'result': 'petrol base engine converted to H2 port injection', 'passed': True})],
    'des.TankSystemIntegration': [],
    'sim.VehicleDynamicsControl': [('Block', 'VDCSimulinkModel', {}), ('Block', 'VDCParameterSet', {})],
}
# features without a default realisation (realised by an extra artefact only)
SKIP_DEFAULT = {'kin.KinematicsForTyreModel'}   # realised only by the sketch KinematicsTables below Suspension (see EXTRA)
# extra artefacts: (role, parent element name, class, name, attrs, also-realises-feature or None)
EXTRA = [
    ('des', 'AccumulatorContainer', 'Sketch', 'CellFixationSketch', {}, None),
    ('des', 'IntakeSystem', 'Assembly', 'ReliefValveAndFlameArrestor', {}, None),
    ('des', 'Fasteners', 'Assembly', 'CriticalBracingBolts', {}, None),
    ('des', 'CombustionEngine', 'Assembly', 'HydrogenConversionParts', {}, None),
    ('des', 'HydrogenConversionParts', 'Box', 'AdaptedCylinderHead', {}, None),
    ('des', 'HydrogenConversionParts', 'Box', 'InjectorAdapters', {}, None),
    ('des', 'PressureRegulator', 'Box', 'RelayContacts', {}, None),
    ('crash', 'MainHoop', 'Box', 'LidarBracket', {}, 'crash.MainHoop'),
    ('kin', 'Suspension', 'Sketch', 'KinematicsTables', {}, 'kin.KinematicsForTyreModel'),
    ('elec', 'SDCHydrogen', 'Circuit', 'OverPressureRelayChain', {}, None),
    ('elec', 'OverPressureRelayChain', 'Device', 'OverPressureRelay1', {'kind': 'Relay'}, None),
    ('elec', 'OverPressureRelayChain', 'Device', 'OverPressureRelay2', {'kind': 'Relay'}, None),
    ('elec', 'TSWiring', 'Circuit', 'PlugDetectionCircuit', {}, None),
    ('elec', 'HighVoltage', 'Device', 'OldInverter', {'kind': 'Inverter', 'ratedVoltage': 600.0}, None),
    ('elec', 'AutonomousSystemElectrics', 'Device', 'CarPC', {'kind': 'ControlUnit'}, None),
    ('elec', 'AutonomousSystemElectrics', 'Device', 'ROS1BridgePort', {'kind': 'Connector'}, None),
    ('elec', 'BrakeSystemPlausibilityDevice', 'Device', 'BSPDTestConnector', {'kind': 'Connector'}, 'elec.BrakeSystemPlausibilityDevice'),
    ('sim', 'AutonomousFunctions', 'Block', 'LidarPoseMainHoop', {}, None),
    ('sim', 'ASStateMachine', 'Block', 'ROS1StateMachineNode', {}, None),
    ('sim', 'StatusIndication', 'Block', 'ROS1StatusNode', {}, None),
    ('sim', 'TSActivationAndReadyToDrive', 'Block', 'PlugDetectionSignal', {}, None),
    ('sim', 'PowerLimitation', 'Block', 'OldInverterInterface', {}, None),
    ('sim', 'Regeneration', 'Block', 'OldInverterRegenInterface', {}, None),
    ('sim', 'PowerLimitation', 'SubSystem', 'CellTemperatureDerating', {}, None),
    ('val', 'TechnicalInspection', 'TestCase', 'BSPDSignalInjectionTest', {'procedure': 'inject a test signal into the BSPD and check the SDC opens'}, None),
]
# overlaps between artefacts (by element name): (role, name, role, name)
EXTRA_OVERLAP = [
    ('des', 'HydrogenStorageSystem', 'crash', 'PrimaryStructure'),
    ('crash', 'AntiIntrusionPlate', 'aero', 'AeroDevices'),
    ('elec', 'CellTemperatureMonitoring', 'sim', 'CellTemperatureDerating'),
    ('thermo', 'WaterInjection', 'des', 'IntakeSystem'),
    ('sim', 'ASStateMachine', 'elec', 'AutonomousSystemElectrics'),
    ('thermo', 'BackfireReliefAnalysis', 'des', 'ReliefValveAndFlameArrestor'),
    ('crash', 'MechanicallyAttachedBracing', 'des', 'CriticalBracingBolts'),
    ('thermo', 'EngineConversionAnalysis', 'des', 'HydrogenConversionParts'),
    ('thermo', 'EngineConversionAnalysis', 'des', 'CV1ChassisAdapterFrame'),
    ('elec', 'OverPressureRelayChain', 'des', 'RelayContacts'),
    ('crash', 'LidarBracket', 'sim', 'LidarPoseMainHoop'),
    ('sim', 'ROS1StateMachineNode', 'elec', 'ROS1BridgePort'),
    ('sim', 'ROS1StatusNode', 'elec', 'ROS1BridgePort'),
    ('elec', 'PlugDetectionCircuit', 'sim', 'PlugDetectionSignal'),
    ('sim', 'VDCParameterSet', 'kin', 'KinematicsTables'),
    ('elec', 'OldInverter', 'sim', 'OldInverterInterface'),
    ('elec', 'OldInverter', 'sim', 'OldInverterRegenInterface'),
    ('val', 'BSPDSignalInjectionTest', 'elec', 'BSPDTestConnector'),
]

FILES = {'prj': 'prj.requirements', 'des': 'des.cad', 'crash': 'crash.cad', 'kin': 'kin.cad', 'aero': 'aero.cad',
         'thermo': 'thermo.thermal', 'elec': 'elec.electrical', 'sim': 'sim.simulink', 'val': 'val.testbench'}
MODELS = {}


def ordered_children(q):
    return children.get(q, [])


# ---- CAD ----------------------------------------------------------------------------
def cad_model(role):
    doc = new('cad', 'CADDocument', name=role.upper())
    m = Model(FILES[role], doc)
    for mat, rho in [('Steel', 7850.0), ('Aluminium', 2700.0), ('CFRP', 1600.0)]:
        doc.materials.append(new('cad', 'Material', name=mat, density=rho))
    steel = doc.materials[0]

    def realise(q, container_ref):
        name = NAME_OVERRIDE.get(q, short(q))
        d = feats[q]
        if q in SKIP_DEFAULT:
            assert is_leaf(q)
            return
        if d.get('type'):
            sk = new('cad', 'Sketch', name=name, label=f'{name} (design parameter)')
            line = new('cad', 'LineSegment', start=new('cad', 'Vector2', x=0.0, y=0.0), end=new('cad', 'Vector2', x=0.1, y=0.0))
            sk.geometries.append(line)
            v = CFG['EV3'].get(q) or CFG['CV2'].get(q) or CFG['CV1'].get(q) or 0
            sk.constraints.append(new('cad', 'Constraint', name=name, type=C('cad', 'ConstraintType').getEEnumLiteral('Distance'),
                                      value=float(v), first=line))
            container_ref.append(m.reg(sk, name))
            feature_corr(q, m.file, name)
            return
        a = new('cad', 'Assembly', name=name, label=name)
        container_ref.append(m.reg(a, name))
        feature_corr(q, m.file, name)
        for c in ordered_children(q):
            realise(c, a.children)
        if is_leaf(q) and not d.get('abstract'):
            content = LEAF_CONTENT.get(q, [('Box', name + 'Part', {})])
            for cls, n, attrs in (content or []):
                o = new('cad', cls, name=n, label=n, **attrs)
                if cls == 'Box':
                    o.length, o.width, o.height, o.material = 0.1, 0.05, 0.02, steel
                a.children.append(m.reg(o, n))
    for c in ordered_children(DOMAIN_ROOT[role]):
        realise(c, doc.objects)
    CORR.append((f'karaceing.uvl#name:{short(DOMAIN_ROOT[role])}', ref(m.file), ''))
    return m


# ---- generic tree domains ------------------------------------------------------------
ELEC_KIND = [('Switch', 'Switch'), ('Button', 'Switch'), ('Relay', 'Relay'), ('Sensor', 'Sensor'), ('Sensing', 'Sensor'),
             ('Monitoring', 'Sensor'), ('Light', 'Indicator'), ('Indicat', 'Indicator'), ('Sound', 'Indicator'), ('Battery', 'Battery'),
             ('Accumulator', 'Battery'), ('Plug', 'Connector'), ('Wiring', 'Connector'), ('Point', 'Connector'), ('Motor', 'Motor'),
             ('Device', 'ControlUnit'), ('Management', 'ControlUnit'), ('Disconnect', 'Switch'), ('Enclosure', 'Other')]
THERMO_KIND = [('Cooling', 'HeatExchanger'), ('ChargeAir', 'HeatExchanger'), ('Exhaust', 'HeatSource'), ('Protection', 'ThermalProtection'),
               ('Shield', 'ThermalProtection'), ('Cover', 'ThermalProtection'), ('Ventilation', 'FluidLine'), ('CatchCan', 'FluidLine'),
               ('Injection', 'FluidLine'), ('Fuel', 'FluidLine'), ('98RON', 'FluidLine')]


def tree_model(role):
    if role == 'elec':
        root = new('electrical', 'ElectricalDesign', name='ELEC'); top = root.elements
    elif role == 'sim':
        root = new('simuLink', 'SimulinkModel', name='SIM', version='R2024b', file='karaceing_control.slx', library=False); top = root.contains
    elif role == 'thermo':
        root = new('thermal', 'ThermalAnalysisModel', name='THERMO'); top = root.elements
    elif role == 'val':
        root = new('testbench', 'TestBenchConfiguration', name='VAL'); top = root.elements
        for n, qn, u in [('Stopwatch', 'time', 's'), ('TiltPlatform', 'angle', 'deg'), ('SoundLevelMeter', 'sound pressure', 'dB(A)'),
                         ('IsolationTester', 'isolation resistance', 'MOhm'), ('BrakeDeceleration', 'deceleration', 'm/s2')]:
            root.instruments.append(new('testbench', 'Instrument', name=n, measuredQuantity=qn, unit=u))
    else:
        raise ValueError(role)
    m = Model(FILES[role], root)
    hv = set()
    stack = ['elec.HighVoltage']
    while stack:
        x = stack.pop(); hv.add(x); stack += children.get(x, [])

    def container(q, name):
        if role == 'elec':
            o = new('electrical', 'Circuit', name=name, voltageClass=C('electrical', 'VoltageClass').getEEnumLiteral('HV' if q in hv else 'LV'),
                    nominalVoltage=600.0 if q in hv else 24.0)
            return o, o.elements
        if role == 'sim':
            o = new('simuLink', 'SubSystem', name=name, tag=short(q)); return o, o.subBlocks
        if role == 'thermo':
            o = new('thermal', 'ThermalSystem', name=name); return o, o.elements
        if role == 'val':
            o = new('testbench', 'TestSuite', name=name); return o, o.elements

    def leaf_content(q, name):
        if q in LEAF_CONTENT:
            out = []
            for cls, n, attrs in (LEAF_CONTENT[q] or []):
                mm = {'thermo': 'thermal', 'sim': 'simuLink', 'elec': 'electrical', 'val': 'testbench'}[role]
                out.append(new(mm, cls, name=n, **attrs))
            return out
        if role == 'elec':
            return [new('electrical', 'Device', name=name + 'Unit', kind=C('electrical', 'DeviceKind').getEEnumLiteral(kw_kind(name, ELEC_KIND, 'Other')))]
        if role == 'sim':
            b = new('simuLink', 'Block', name=name + 'Logic')
            b.parameters.append(new('simuLink', 'Parameter', name='SampleTime', type='double', value='0.001', readOnly=False))
            return [b]
        if role == 'thermo':
            k = kw_kind(name, THERMO_KIND, 'AnalysisCase')
            n = name + ('Analysis' if k == 'AnalysisCase' else 'Element')
            o = new('thermal', k, name=n)
            if k == 'AnalysisCase':
                o.method, o.passed = 'thermal analysis', True
            return [o]
        return []

    def realise(q, container_ref):
        name = NAME_OVERRIDE.get(q, short(q))
        d = feats[q]
        if role == 'val' and is_leaf(q):
            o = new('testbench', 'TestCase', name=name, procedure=f'Procedure of {name}', passCriterion='according to the rules')
            o.steps.append(new('testbench', 'TestStep', name=name + 'Setup', description='prepare the car'))
            o.steps.append(new('testbench', 'TestStep', name=name + 'Execution', description='run the test'))
            container_ref.append(m.reg(o, name)); feature_corr(q, m.file, name); return
        if role == 'thermo' and d.get('type'):
            o = new('thermal', 'ThermalProtection', name=name, material='silicone', temperatureResistance=float(CFG['EV3'].get(q) or 120))
            container_ref.append(m.reg(o, name)); feature_corr(q, m.file, name); return
        o, sub = container(q, name)
        container_ref.append(m.reg(o, name))
        feature_corr(q, m.file, name)
        for c in ordered_children(q):
            realise(c, sub)
        if is_leaf(q) and not d.get('abstract'):
            for x in leaf_content(q, name):
                sub.append(m.reg(x, x.name))

    for c in ordered_children(DOMAIN_ROOT[role]):
        realise(c, top)
    CORR.append((f'karaceing.uvl#name:{short(DOMAIN_ROOT[role])}', ref(m.file), ''))
    return m


# ---- requirements (PRJ) --------------------------------------------------------------
rows = []
for f in sorted(glob.glob(f'{SPL}/mapping/*_mapping.csv')):
    rows += list(csv.DictReader(open(f, encoding='utf-8-sig'), delimiter=';'))
REQ_FEATURES = defaultdict(list)
REQ_ROW = OrderedDict()
for r in rows:
    REQ_FEATURES[r['Item_ID']].append(r['Feature'])
    REQ_ROW.setdefault(r['Item_ID'], r)
KIND = {'Anforderung': 'Requirement', 'Ziel': 'Goal', 'Funktion': 'Function'}


def requirement(r):
    q = new('requirements', 'Requirement', name=r['Item_ID'], text=r['Beschreibung_kurz'], subteam=r['Subteam'], category=r['Subkategorie'],
            unit=r['Einheit'], priority=r['Prioritaet'], role=r['Role'], kind=C('requirements', 'RequirementKind').getEEnumLiteral(KIND[r['Typ']]))
    for code, label, fn, col in CARS:
        v = (r.get(col) or '').strip()
        if v:
            q.carValues.append(new('requirements', 'CarValue', name=code, value=v))
    return q


def req_model():
    spec = new('requirements', 'RequirementsSpecification', name='PRJ',
               description='Requirements specification of the KA-RaceIng product line (EV3, CV2, CV1)')
    m = Model(FILES['prj'], spec)
    sec_of = {}

    def realise(q, container_ref):
        name = short(q)
        s = new('requirements', 'Section', name=name, description=f'Requirements and decisions for {name}')
        container_ref.append(m.reg(s, name))
        feature_corr(q, m.file, name)
        sec_of[q] = s
        for c in ordered_children(q):
            realise(c, s.sections)
    for c in ordered_children(DOMAIN_ROOT['prj']):
        realise(c, spec.sections)
    sec_of[DOMAIN_ROOT['prj']] = None
    dom = new('requirements', 'Section', name='DomainRequirements', description='Requirements realised by the other stakeholder roles')
    spec.sections.append(m.reg(dom, 'DomainRequirements'))
    role_sec = {}
    for rid, r in REQ_ROW.items():
        fs = REQ_FEATURES[rid]
        prj_fs = [f for f in fs if role_of(f) == 'prj']
        req = requirement(r)
        if prj_fs and sec_of.get(prj_fs[0]) is not None:
            sec_of[prj_fs[0]].requirements.append(m.reg(req, rid))
        elif prj_fs:
            spec_root_sec = role_sec.setdefault('PRJ', None)
            if spec_root_sec is None:
                spec_root_sec = new('requirements', 'Section', name='PRJRequirements', description='General project requirements')
                dom.sections.append(m.reg(spec_root_sec, 'PRJRequirements')); role_sec['PRJ'] = spec_root_sec
            spec_root_sec.requirements.append(m.reg(req, rid))
        else:
            rc = r['Role']
            if rc not in role_sec:
                s = new('requirements', 'Section', name=rc + 'Requirements', description=f'Requirements realised by {r["Stakeholder"]}')
                dom.sections.append(m.reg(s, rc + 'Requirements')); role_sec[rc] = s
            role_sec[rc].requirements.append(m.reg(req, rid))
    CORR.append((f'karaceing.uvl#name:{short(DOMAIN_ROOT["prj"])}', ref(m.file), ''))
    return m


# ---- build all ----------------------------------------------------------------------
MODELS['prj'] = req_model()
for r in CAD_ROLES:
    MODELS[r] = cad_model(r)
for r in ['elec', 'sim', 'thermo', 'val']:
    MODELS[r] = tree_model(r)


def find_parent(role, name):
    return MODELS[role].by_name[name]


def child_ref(o):
    cn = o.eClass.name
    return {'Assembly': 'children', 'Circuit': 'elements', 'SubSystem': 'subBlocks', 'ThermalSystem': 'elements', 'TestSuite': 'elements'}[cn]


MMOF = {'des': 'cad', 'crash': 'cad', 'kin': 'cad', 'aero': 'cad', 'elec': 'electrical', 'sim': 'simuLink', 'thermo': 'thermal', 'val': 'testbench'}
for role, parent, cls, name, attrs, realises in EXTRA:
    p = find_parent(role, parent)
    a = dict(attrs)
    if 'kind' in a:
        a['kind'] = C('electrical', 'DeviceKind').getEEnumLiteral(a['kind'])
    o = new(MMOF[role], cls, name=name, **a)
    if cls == 'Box':
        o.length, o.width, o.height = 0.05, 0.05, 0.01
    if cls == 'Sketch':
        line = new('cad', 'LineSegment', start=new('cad', 'Vector2', x=0.0, y=0.0), end=new('cad', 'Vector2', x=0.2, y=0.0))
        o.geometries.append(line)
        o.constraints.append(new('cad', 'Constraint', name=name + 'Length', type=C('cad', 'ConstraintType').getEEnumLiteral('Distance'), value=0.2, first=line))
    getattr(p, child_ref(p)).append(MODELS[role].reg(o, name))
    if realises:
        feature_corr(realises, MODELS[role].file, name)

# overlaps: interface constraints between roles (except PRJ variant drivers) + scenario overlaps
OVERLAP = []


def vars_of(e):
    if e[0] == 'var': return [e[1]]
    out = []
    for x in e[1:]:
        if isinstance(x, tuple): out += vars_of(x)
    return out


for name, txt, e in CONSTRAINTS:
    vs = [v for v in dict.fromkeys(vars_of(e)) if role_of(v) not in (None, 'prj')]
    for i, a in enumerate(vs):
        for b in vs[i + 1:]:
            if role_of(a) != role_of(b):
                OVERLAP.append((a, b, f'interface constraint {name}: {txt}'))
seen = set()
for a, b, why in OVERLAP:
    fa, na = REALISATION[a]; fb, nb = REALISATION[b]
    key = tuple(sorted([(fa, na), (fb, nb)]))
    if key in seen: continue
    seen.add(key)
    CORR.append((ref(fa, na), ref(fb, nb), 'overlap'))
for ra, na, rb, nb in EXTRA_OVERLAP:
    assert na in MODELS[ra].names and nb in MODELS[rb].names, (ra, na, rb, nb)
    key = tuple(sorted([(FILES[ra], na), (FILES[rb], nb)]))
    if key in seen: continue
    seen.add(key)
    CORR.append((ref(FILES[ra], na), ref(FILES[rb], nb), 'overlap'))

# requirement traces: requirement <-> artefact realising each mapped (non-PRJ) feature
for rid, fs in REQ_FEATURES.items():
    for q in dict.fromkeys(fs):
        if role_of(q) == 'prj' or q not in REALISATION:
            continue
        f, n = REALISATION[q]
        CORR.append((ref('prj.requirements', rid), ref(f, n), 'requirement'))

# ---- BOM and brake system ---------------------------------------------------------------
bom = new('bom', 'BOM', name='KA-RaceIng BOM')
types = {}
for tn, desc in [('Part', 'manufactured part'), ('Assembly', 'assembly'), ('PurchasedPart', 'purchased part'), ('Fastener', 'standard part'),
                 ('ElectricalComponent', 'electrical / electronic component')]:
    t = new('bom', 'ItemType', name=tn, description=desc)
    t.parameterDefinitions.append(new('bom', 'ParameterDefinition', name='mass', dataType=C('bom', 'DataType').getEEnumLiteral('EDouble')))
    t.parameterDefinitions.append(new('bom', 'ParameterDefinition', name='material', dataType=C('bom', 'DataType').getEEnumLiteral('EString')))
    bom.itemTypes.append(t); types[tn] = t
BOM_IDS = set()


def bom_item(item_id, tname, file, name, n=1, material='Steel'):
    assert item_id not in BOM_IDS, item_id
    BOM_IDS.add(item_id)
    it = new('bom', 'Item', id=item_id, type=types[tname], numberOfItems=n)
    it.parameterValues.append(new('bom', 'DoubleParameterValue', definition=types[tname].parameterDefinitions[0], value=0.5, unit='kg'))
    it.parameterValues.append(new('bom', 'StringParameterValue', definition=types[tname].parameterDefinitions[1], value=material))
    bom.items.append(it)
    CORR.append((ref(file, name), f'karaceing.bom#name:{item_id}', 'overlap'))


for role in CAD_ROLES:
    m = MODELS[role]
    for n, o in m.by_name.items():
        if o.eClass.name == 'Box':
            bom_item(f'{role.upper()}-{n}', 'Part', m.file, n)
bom_item('DES-HydrogenTank', 'PurchasedPart', 'des.cad', 'HydrogenTank', material='CFRP')
bom_item('DES-CriticalBracingBolts', 'Fastener', 'des.cad', 'CriticalBracingBolts', n=8)
bom_item('ELEC-OldInverter', 'ElectricalComponent', 'elec.electrical', 'OldInverter', material='-')

brake = new('brakesystem', 'Brakesystem', instanceName='BRAKE', specificationType='hydraulic dual circuit')
for cls, cid, attrs in [('BrakeDisk', 'FrontBrakeDisk', dict(diameterInMM=220, brakeDiskThicknessInMM=4, minimumThicknessInMM=3, ventilated=False)),
                        ('BrakeDisk', 'RearBrakeDisk', dict(diameterInMM=200, brakeDiskThicknessInMM=4, minimumThicknessInMM=3, ventilated=False)),
                        ('BrakeCaliper', 'FrontBrakeCaliper', dict(pistonDiameterInMM=25, brakeDiskThicknessInMM=4)),
                        ('BrakeCaliper', 'RearBrakeCaliper', dict(pistonDiameterInMM=22, brakeDiskThicknessInMM=4)),
                        ('BrakeHose', 'FrontBrakeHose', dict(threadSize1='M10x1', threadSize2='M10x1', lengthInMM=450))]:
    o = new('brakesystem', cls, id=cid, fittingPosition='front' if 'Front' in cid else 'rear', specificationType='KA-RaceIng', **attrs)
    brake.BrakeComponents.append(o)
    CORR.append((f'des.brakesystem#name:{cid}', ref('des.cad', 'HydraulicBrakes'), 'overlap'))

# ---- UVL <-> config and feature <-> config feature --------------------------------------------
CORR.append(('karaceing.uvl#', 'karaceing.config#', ''))
CORR.append(('karaceing.uvl#', UVL_MODEL_LITERAL, ''))
for code, *_ in CARS:
    for q in FEATURE:
        CORR.append((FEATURE[q], CONFIG_FEATURE[code][q], ''))


# ----------------------------------------------------------------------------- write the persisted VSUM
import hashlib, shutil
from xml.sax.saxutils import quoteattr

PLACEHOLDER = 'file:/KARACEING_INITIAL_STATE'
ROOTS = OrderedDict([('karaceing.uvl', uvl), ('karaceing.config', config_model)])
for role, m in MODELS.items():
    ROOTS[m.file] = m.root
ROOTS['karaceing.bom'] = bom
ROOTS['des.brakesystem'] = brake
FILE_OF_ROOT = {id(r): f for f, r in ROOTS.items()}


def root_of(o):
    while o.eContainer() is not None:
        o = o.eContainer()
    return o


def path_segments(o):
    """EMF URI fragment segments (EObjectImpl.eURIFragmentSegment): @feature or @feature.index."""
    segs = []
    while o.eContainer() is not None:
        f = o.eContainmentFeature()
        c = o.eContainer()
        segs.append(f'@{f.name}.{list(c.eGet(f)).index(o)}' if f.many else f'@{f.name}')
        o = c
    return list(reversed(segs))


def resolve_name_ref(reference):
    """'<file>#' (root) or '<file>#name:X[/name:Y]' (first element below with that name / id / instanceName)."""
    file, path = reference.split('#', 1)
    cur = ROOTS[file]
    for seg in [p for p in path.split('/') if p]:
        name = seg.split(':', 1)[1]
        cur = next(x for x in cur.eAllContents()
                   if any(getattr(x, a, None) == name for a in ('name', 'id', 'instanceName') if x.eClass.findEStructuralFeature(a)))
    return cur


def href(o):
    """href from vsum/correspondences.correspondence to the element (EMF default XMI fragment)."""
    if o is UVL_MODEL_LITERAL:
        return 'http://vitruv.tools/methodologisttemplate/uvl#//UVLModel'
    segs = path_segments(o)
    return f'../{FILE_OF_ROOT[id(root_of(o))]}#/' + ('/' + '/'.join(segs) if segs else '')


def obj(x):
    return x if not isinstance(x, str) else resolve_name_ref(x)


# ---- every artefact corresponds to a feature ------------------------------------------------
# Rule (Fabian, 2026-10-25): an artefact without a feature is not allowed. Artefacts are all elements of the
# solution-space models that represent something; value objects inside them are exempt. Elements that are
# not the main realisation of a feature (generated details such as ...Part / ...Unit / ...Logic, the
# scenario-specific artefacts, the role sections of the requirements specification, instruments) get the
# feature of their containing element; requirements get the features they are mapped to in the mapping;
# BOM items and brake components get the features of the CAD element they overlap with.
EXEMPT = {'Material', 'LineSegment', 'Circle', 'Vector2', 'Constraint', 'Parameter', 'TestStep', 'CarValue', 'ItemType',
          'ParameterDefinition', 'StringParameterValue', 'DoubleParameterValue', 'IntegerParameterValue', 'BoolParameterValue',
          'Pin', 'BusSignalMapping', 'IdentifierReference', 'LibraryLinkReference'}
ARTEFACT_FILES = [m.file for m in MODELS.values()] + ['karaceing.bom', 'des.brakesystem']


def elem_ref(o):
    f = FILE_OF_ROOT[id(root_of(o))]
    if o.eContainer() is None:
        return ref(f)
    n = getattr(o, 'name', None) or getattr(o, 'id', None) or getattr(o, 'instanceName', None)
    assert n, o
    return ref(f, n)


FEATURES_OF = defaultdict(list)             # id(artefact) -> feature refs ('karaceing.uvl#name:X')
for a, b, t in CORR:
    if t == '' and isinstance(a, str) and a.startswith('karaceing.uvl#name:') and isinstance(b, str) and b.split('#')[0] in ARTEFACT_FILES:
        FEATURES_OF[id(obj(b))].append(a)
OVERLAP_OF = defaultdict(list)
for a, b, t in CORR:
    if t == 'overlap':
        oa, ob = obj(a), obj(b)
        OVERLAP_OF[id(oa)].append(ob); OVERLAP_OF[id(ob)].append(oa)
added = defaultdict(int)


def map_to(o, feature_refs, why):
    for fr in dict.fromkeys(feature_refs):
        CORR.append((fr, elem_ref(o), ''))
        FEATURES_OF[id(o)].append(fr)
    added[why] += 1


# requirements -> mapped features (all of them, PRJ features included)
for req in [x for x in ROOTS['prj.requirements'].eAllContents() if x.eClass.name == 'Requirement']:
    map_to(req, [f'karaceing.uvl#name:{short(q)}' for q in REQ_FEATURES[req.name]], 'requirement -> mapped features')
# all remaining artefacts: feature of the nearest containing element that has one (parents before children; the
# role models first, so that BOM items and brake components find the features of the overlapping CAD elements)
for fn in [m.file for m in MODELS.values()] + ['karaceing.bom', 'des.brakesystem']:
    root = ROOTS[fn]
    for o in [root] + list(root.eAllContents()):
        if o.eClass.name in EXEMPT or FEATURES_OF[id(o)]:
            continue
        if fn in ('karaceing.bom', 'des.brakesystem') and o.eContainer() is not None:
            fs = [fr for p in OVERLAP_OF[id(o)] for fr in FEATURES_OF[id(p)]]
            if fs:
                map_to(o, fs, f'{fn}: feature of the overlapping CAD element'); continue
        if o is ROOTS['karaceing.bom']:
            map_to(o, ['karaceing.uvl#name:KARaceIngSPL'], 'BOM root -> root feature'); continue
        if o is ROOTS['des.brakesystem']:
            map_to(o, FEATURES_OF[id(obj(ref('des.cad', 'HydraulicBrakes')))], 'brake system root -> HydraulicBrakes'); continue
        p = o.eContainer()
        while p is not None and not FEATURES_OF[id(p)]:
            p = p.eContainer()
        assert p is not None, (fn, o)
        map_to(o, FEATURES_OF[id(p)][:1], f'{fn.split(".")[1]}: feature of the containing element')
missing = [(fn, o.eClass.name, getattr(o, 'name', None)) for fn in ARTEFACT_FILES for o in [ROOTS[fn]] + list(ROOTS[fn].eAllContents())
           if o.eClass.name not in EXEMPT and not FEATURES_OF[id(o)]]
assert not missing, missing[:10]
print('feature correspondences added for artefacts without feature:', dict(added))

for fn, root in ROOTS.items():
    r = rs.create_resource(URI(f'{OUT}/{fn}'))
    r.append(root)
    r.save()

vsum_dir = os.path.join(OUT, 'vsum')
shutil.rmtree(vsum_dir, ignore_errors=True)
os.makedirs(vsum_dir)
old_csv = os.path.join(OUT, 'correspondences.csv')
if os.path.exists(old_csv):
    os.remove(old_csv)
with open(os.path.join(vsum_dir, 'models.models'), 'w') as fh:
    for fn in ROOTS:
        fh.write(f'{PLACEHOLDER}/{fn}\n')


def uuid_for(key):
    """Deterministic UUID in the form Vitruvius generates ("ord_" + EcoreUtil.generateUUID())."""
    import base64
    digest = base64.urlsafe_b64encode(hashlib.sha1(key.encode()).digest()[:16]).decode().rstrip('=')
    return 'ord__' + digest


with open(os.path.join(vsum_dir, 'uuid.uuid'), 'w') as fh:
    for fn, root in ROOTS.items():
        for o in [root] + list(root.eAllContents()):
            segs = path_segments(o)
            hid = f'{PLACEHOLDER}/{fn}#/0' + ('/' + '/'.join(segs) if segs else '')
            fh.write(f'{uuid_for(hid)}|{hid}\n')

lines = ['<?xml version="1.0" encoding="ASCII"?>',
         '<correspondence:Correspondences xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" '
         'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" '
         'xmlns:correspondence="http://vitruv.tools/metamodels/change/correspondence/1.0" '
         'xmlns:correspondence_1="http://vitruv.tools/metamodels/dsls/reactions/runtime/correspondence/1.0">']
for a, b, t in CORR:
    lines.append(f'  <correspondences xsi:type="correspondence_1:ReactionsCorrespondence" tag={quoteattr(t)}>')
    lines.append(f'    <leftEObjects href={quoteattr(href(obj(a)))}/>')
    lines.append(f'    <rightEObjects href={quoteattr(href(obj(b)))}/>')
    lines.append('  </correspondences>')
lines.append('</correspondence:Correspondences>')
with open(os.path.join(vsum_dir, 'correspondences.correspondence'), 'w', encoding='ascii', errors='xmlcharrefreplace') as fh:
    fh.write('\n'.join(lines) + '\n')

stats = defaultdict(int)
for a, b, t in CORR: stats[t or 'feature/config'] += 1
print('features', len(FEATURE), 'constraints', len(CONSTRAINTS), 'requirements', len(REQ_ROW), 'bom items', len(BOM_IDS))
print('elements per model', {r: len(m.names) for r, m in MODELS.items()})
print('correspondences', dict(stats))
